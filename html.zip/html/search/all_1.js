var searchData=
[
  ['funkcionalnost_0',['Funkcionalnost',['../md__read_m_e.html#autotoc_md7',1,'']]]
];
