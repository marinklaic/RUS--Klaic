var searchData=
[
  ['opis_0',['Opis',['../md__read_m_e.html#autotoc_md1',1,'']]]
];
