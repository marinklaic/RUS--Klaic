var searchData=
[
  ['zaključak_0',['Zaključak',['../md__read_m_e.html#autotoc_md11',1,'']]]
];
